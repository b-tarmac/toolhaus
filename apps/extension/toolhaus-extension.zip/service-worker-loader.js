import './assets/service-worker.ts-BP0d1Lyq.js';
